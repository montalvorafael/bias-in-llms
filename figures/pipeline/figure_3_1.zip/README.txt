FIGURA 3.1: PROPUESTA PARA REVISION

Recreacion vectorial de la figura de recoleccion de datos, conservando cinco etapas y la paleta del original.

Correcciones:
- 14 valores reales en cuatro dimensiones; se incluye edad.
- Se eliminan non-binary, European, African, Middle Eastern, CEO y developer como valores que no corresponden al estudio; se conservan las etiquetas reales del dataset, incluido Middle East como origen geografico.
- 12 plantillas x 14 valores = 168 prompts; dimensiones evaluadas por separado.
- Seis modelos, temperatura 0, limite de 200 tokens y una respuesta por combinacion.
- 168 prompts x 6 modelos = 1,008 respuestas; 72 por valor de atributo.
- Esquema exacto del CSV: prompt_id, scenario, attribute_dimension, attribute_value, model_name, response_text.
- El ejemplo de plantilla reproduce T1 del Colab del autor.

Fuente y herramientas:
La propuesta fue dibujada mediante un script Python con Pillow y elementos vectoriales SVG, con asistencia de ChatGPT. No se uso un generador de imagenes para esta reconstruccion. El archivo .drawio contiene formas, lineas y texto editables; no es una imagen pegada. Puede abrirse en app.diagrams.net mediante File > Open from > Device. El SVG es vectorial editable y el PNG es una exportacion de alta resolucion.

Esto no identifica la herramienta que produjo la figura original. Su procedencia sigue pendiente de confirmacion por el autor. La declaracion de asistencia de IA debera reflejar la recreacion si se integra, segun las indicaciones del asesor.

Esta propuesta todavia no se ha integrado a la tesis: esta pendiente del visto bueno del autor.
